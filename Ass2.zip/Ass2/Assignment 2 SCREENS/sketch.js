let fighterImg;
let imgEnemy1;
let imgBullet;
let x = 65;
let score = 0;
let play = 0;
let loser = 1;
let currentScreen = play;


function preload() {
    fighterImg = loadImage('fighter1.png');
    imgEnemy1 = loadImage('Enemy1.png')
    imgBullet = loadImage('bullet.png');


}
let fighter;
let enemies = [];
let enemiesGroup;
let bullets;
let walls;
let fires = [];

function setup() {
    createCanvas(1300, 700);
    enemiesGroup = new Group();
    bullets = new Group();
    walls = new Group();
    let bot = createSprite(650, 700, 1300, 10);
    let left = createSprite(-10, 350, 10, 700);
    let right = createSprite(1300, 350, 10, 700);
    walls.add(bot);
    walls.add(left);
    walls.add(right);

    //Create Sprites and add to Group
    for (let i = 0; i < 6; i++) {
        for (let j = 0; j < 20; j++) {
            let aX = 200 + j * 50;
            let aY = 50 + i * 50;
            createAlien(aX, aY);
        }
    }

    //Create Objects Array
    for (let i = 0; i < 10; i++) {
        enemies.push({
            alien: {},
            x: 20,
            y: 50 - i * 50,
            w: 100,
            speed: 4.5,
            angle: 90,
            show: function () {
                this.alien = createSprite(this.x, this.y, this.w, this.w);
                this.alien.addAnimation('fly', 'Enemy1.png', 'Enemy1.1.png');
            },
            move: function () {
                this.alien.setSpeed(this.speed, this.angle);
                if (this.alien.position.y > height * 0.5) {
                    this.alien.addSpeed(50, 1);

                }
            }
        });
    }
    for (let i = 0; i < enemies.length; i++) {
        enemies[i].show();
        enemiesGroup.add(enemies[i].alien);
    }
    for (let i = 0; i < walls.length; i++) {
        walls[i].immovable = true;
    }

    fighter = createSprite(650, 650, 100, 100);
    fighter.addImage(fighterImg);
    fighter.friction = 0.01;

    print(enemies);
    print(enemiesGroup);
}

function draw() {
    if (currentScreen == play) {
        playIt()
    } else {
        loseIt();
    }

}

function playIt() {
    background(0);
    drawSprites();
    stroke('white');
    textSize(50);
    text('Score: ' + score, 1000, 100);
    keys();
    for (i = 0; i < enemies.length; i++) {
        enemies[i].move();
        enemiesGroup.rotateToDirection = true
    }
    enemiesGroup.overlap(bullets, explode);
    enemiesGroup.bounce(walls, drop);
    fighter.overlap(enemiesGroup, lose);
    print(enemiesGroup.length);
    if (enemiesGroup.length < 10) {
        for (let i = 0; i < 6; i++) {
            for (let j = 0; j < 20; j++) {
                let aX = 200 + j * 50;
                let aY = 50 + i * 50;
                createAlien(aX, aY);
            }
        }
    }
}

function loseIt() {
    background(0);
    stroke('white');
    textSize(50);
    textAlign(CENTER);
    text("Your Score: " + score, width / 2, height / 2);
    text("Rip Gamer", width / 2, height / 4);

}


function keys() {
    if (keyIsDown(RIGHT_ARROW)) {
        fighter.setSpeed(8, 0);
    } else if (keyIsDown(LEFT_ARROW)) {
        fighter.setSpeed(8, 180);
    } else {
        fighter.setSpeed(0, 0)
    }
}

function mouseClicked() {
    createBullet(fighter.position.x, fighter.position.y);
}


function createAlien(x, y) {
    let alien = createSprite(x, y, 100, 100);
    alien.addAnimation('fly', 'Enemy1.png', 'Enemy1.1.png');
    alien.setSpeed(4.5, 0);
    enemiesGroup.add(alien);
}

function createBullet(x, y) {
    let bullet = createSprite(x, y);
    bullet.addImage(imgBullet);
    bullet.setSpeed(10, 270);

    bullets.add(bullet);
    print(bullets);

    return bullet;
}

function explode(spriteA, spriteB) {
    for (let i = 0; i < 10; i++) {
        let fire = createSprite(spriteA.position.x, spriteA.position.y, 100, 100);
        fire.addAnimation('blow', 'campfire0.png', 'campfire3.png');
        fire.setSpeed(random(2, 4), random(360));
        fire.life = 20;
    }
    spriteA.remove();
    spriteB.remove();
    score += 20;
}

function drop(spriteA, spriteB) {
    spriteA.position.y += 50;
}

function lose() {
    currentScreen = loser;
}
